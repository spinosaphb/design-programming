
### Convetions
- The cli.ts file is the entry point of the activity

### To run the activity

```bash
./run.sh <project_path> <filename>.ts
```

### Example

```bash
./run.sh graphite cli.ts
```